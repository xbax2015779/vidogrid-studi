import { NextResponse } from "next/server";
export async function GET(_req: Request, context: { params: Promise<{ uuid: string }> }) {
  const key = process.env.VIDOGRID_API_KEY;
  if (!key) return NextResponse.json({ error: "Server is missing VIDOGRID_API_KEY." }, { status: 500 });
  const { uuid } = await context.params;
  if (!uuid || uuid.length > 200 || !/^[a-zA-Z0-9_-]+$/.test(uuid)) return NextResponse.json({ error: "Invalid job ID." }, { status: 400 });
  try {
    const upstream = await fetch(`https://api.vidogrid.ai/uapi/v1/history/${encodeURIComponent(uuid)}`, {
      headers: { "x-api-key": key }, cache: "no-store"
    });
    const raw = await upstream.text();
    let data: any; try { data = JSON.parse(raw); } catch { data = { raw }; }
    return NextResponse.json(data, { status: upstream.status });
  } catch {
    return NextResponse.json({ error: "Could not check generation status." }, { status: 502 });
  }
}