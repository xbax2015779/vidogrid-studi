import { NextResponse } from "next/server";

const BASE = "https://api.vidogrid.ai/uapi/v1";
const allowed: Record<string,string> = {
  "veo-3.1-fast": "veo",
  "grok-imagine-video-1.5": "grok-imagine-video-1.5",
  "muse": "meta"
};

export async function POST(req: Request) {
  const key = process.env.VIDOGRID_API_KEY;
  if (!key) return NextResponse.json({ error: "Server is missing VIDOGRID_API_KEY. Add it in Vercel → Project Settings → Environment Variables, then redeploy." }, { status: 500 });
  try {
    const body = await req.json();
    const model = String(body.model || "");
    if (!allowed[model] || body.endpoint !== allowed[model]) return NextResponse.json({ error: "Unsupported model." }, { status: 400 });
    const prompt = String(body.prompt || "").trim();
    if (!prompt || prompt.length > 3000) return NextResponse.json({ error: "Enter a prompt (maximum 3000 characters)." }, { status: 400 });
    const form = new FormData();
    form.set("model", model);
    form.set("prompt", prompt);
    if (body.duration) form.set("duration", String(body.duration));
    if (body.aspect_ratio) form.set("aspect_ratio", String(body.aspect_ratio));
    if (body.resolution) form.set("resolution", String(body.resolution));
    const upstream = await fetch(`${BASE}/video-gen/${allowed[model]}`, {
      method: "POST", headers: { "x-api-key": key }, body: form, cache: "no-store"
    });
    const raw = await upstream.text();
    let data: any; try { data = JSON.parse(raw); } catch { data = { raw }; }
    return NextResponse.json(data, { status: upstream.status });
  } catch {
    return NextResponse.json({ error: "The request could not be processed." }, { status: 500 });
  }
}