import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "VidoGrid Studio",
  description: "A private companion for generating videos with VidoGrid."
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}