 "use client";
import { useEffect, useState } from "react";

const models = [
  { id: "veo-3.1-fast", name: "Veo 3.1 Fast", endpoint: "veo", note: "Fast cinematic video" },
  { id: "grok-imagine-video-1.5", name: "Grok Imagine Video 1.5", endpoint: "grok-imagine-video-1.5", note: "Text or reference-image video" },
  { id: "muse", name: "Muse AI", endpoint: "meta", note: "Muse video generation" }
];

function findVideoUrl(value: any): string | null {
  if (!value || typeof value !== "object") return null;
  for (const [key, v] of Object.entries(value)) {
    if (typeof v === "string" && /^(video_url|url|download_url|output_url)$/i.test(key) && /^https?:\/\//.test(v)) return v;
    if (v && typeof v === "object") { const found = findVideoUrl(v); if (found) return found; }
  }
  return null;
}

export default function Home() {
  const [model, setModel] = useState(models[0].id);
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState("15");
  const [ratio, setRatio] = useState("16:9");
  const [resolution, setResolution] = useState("720p");
  const [uuid, setUuid] = useState("");
  const [status, setStatus] = useState("");
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const selected = models.find(m => m.id === model)!;
  async function generate(e: React.FormEvent) {
    e.preventDefault();
    setError(""); setResult(null); setUuid(""); setStatus("Submitting request…"); setBusy(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST", headers: {"Content-Type":"application/json"},
        body: JSON.stringify({ model, endpoint: selected.endpoint, prompt, duration: Number(duration), aspect_ratio: ratio, resolution })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not submit generation.");
      const id = data.uuid || data.data?.uuid || data.job?.uuid || data.id;
      if (!id) { setResult(data); setStatus("Request accepted; response did not include a recognizable job ID."); setBusy(false); return; }
      setUuid(id); setStatus("Queued — waiting for your video…");
    } catch (err: any) { setError(err.message || "Something went wrong."); setStatus(""); setBusy(false); }
  }

  useEffect(() => {
    if (!uuid) return;
    let stopped = false;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      try {
        const res = await fetch(`/api/status/${encodeURIComponent(uuid)}`, { cache: "no-store" });
        const data = await res.json();
        if (stopped) return;
        setResult(data);
        const raw = JSON.stringify(data).toLowerCase();
        const video = findVideoUrl(data);
        if (video) { setStatus("Your video is ready."); setBusy(false); return; }
        if (/(failed|error|cancelled)/.test(raw)) { setStatus("Generation failed. See details below."); setBusy(false); return; }
        setStatus("Generating… checking again in a few seconds.");
        timer = setTimeout(poll, 5000);
      } catch {
        if (!stopped) { setStatus("Status check hiccup — retrying…"); timer = setTimeout(poll, 7000); }
      }
    };
    poll();
    return () => { stopped = true; clearTimeout(timer); };
  }, [uuid]);

  const videoUrl = findVideoUrl(result);
  return <main className="shell">
    <header className="top"><div className="brand"><span className="mark">▶</span><span>VIDOGRID <b>STUDIO</b></span></div><span className="secure">● Private API connection</span></header>
    <section className="hero"><div className="eyebrow">YOUR AI VIDEO WORKSHOP</div><h1>Make something<br/><em>incredible.</em></h1><p>Choose a model, describe your scene, and send it to VidoGrid.</p></section>
    <section className="panel">
      <form onSubmit={generate}>
        <label>MODEL</label>
        <div className="models">{models.map(m => <button type="button" key={m.id} className={`model ${model===m.id?"chosen":""}`} onClick={()=>setModel(m.id)}><strong>{m.name}</strong><small>{m.note}</small></button>)}</div>
        <div className="labelrow"><label htmlFor="prompt">YOUR PROMPT</label><span>{prompt.length}/3000</span></div>
        <textarea id="prompt" maxLength={3000} value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Two exotic racing cars battling for first place on a professional race track at sunset. Low tracking camera, tire smoke, dramatic overtakes, realistic motorsport footage…" required />
        <div className="options">
          <div><label htmlFor="duration">DURATION</label><select id="duration" value={duration} onChange={e=>setDuration(e.target.value)}><option value="5">5 seconds</option><option value="6">6 seconds</option><option value="8">8 seconds</option><option value="10">10 seconds</option><option value="15">15 seconds</option></select></div>
          <div><label htmlFor="ratio">ASPECT RATIO</label><select id="ratio" value={ratio} onChange={e=>setRatio(e.target.value)}><option>16:9</option><option>9:16</option><option>1:1</option></select></div>
          <div><label htmlFor="resolution">RESOLUTION</label><select id="resolution" value={resolution} onChange={e=>setResolution(e.target.value)}><option>720p</option><option>1080p</option></select></div>
        </div>
        <button className="submit" disabled={busy || !prompt.trim()}>{busy ? "WORKING…" : "✦  GENERATE VIDEO"}</button>
      </form>
      {status && <div className="status"><span className={busy?"pulse":"dot"} />{status}{uuid && <small>Job: {uuid}</small>}</div>}
      {error && <div className="error">{error}</div>}
      {videoUrl && <div className="video"><video controls playsInline src={videoUrl}/><a href={videoUrl} target="_blank" rel="noreferrer">Open / download video ↗</a></div>}
      {result && !videoUrl && <details><summary>Generation response details</summary><pre>{JSON.stringify(result,null,2)}</pre></details>}
    </section>
    <footer>VidoGrid Studio · Your API key stays on the server, never in browser code.</footer>
  </main>;
}